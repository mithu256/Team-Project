@extends('medicie_stocks.layout')

@section('content')
<div class="pull-left">
    <h2>Stock </h2>
</div>
<div class="row">
    <div class="col-lg-12 margin-tb">

        <div class="pull-right">
             <a class="btn btn-success" href="{{route('medicine_stocks.create')}}">Create Stock</a>
        </div>
    </div>
</div>

@if($message=Session::get('success'))
    <div class="alert alert-success">
         <p>{{$message}}</p>
    </div>
@endif

<table class="table table-bordered">
<tr>
    <th>Med_No</th>
    <th>Med_Name</th>
    <th>Dosage</th>
    <th>Consumption_time</th>
    <th>Unit_Price</th>
    <th>Exp_Date</th>
    <th>Manu_Date</th>
    <th>Quantity</th>
    <th width="280px">Action</th>

</tr>

    @foreach($medicine_stocks as $medicine_stock)
    <tr>
        <td>{{++$i}}</td>
        <td>{{$medicine_stock->Med_Name}}</td>
        <td>{{$medicine_stock->Dosage}}</td>
        <td>{{$medicine_stock->Consumption_time}}</td>
        <td>{{$medicine_stock->Unit_Price}}</td>
        <td>{{$medicine_stock->Exp_Date}}</td>
        <td>{{$medicine_stock->Manu_Date}}</td>
        <td>{{$medicine_stock->Quantity}}</td>

        <td>
          <form action="{{route('medicine_stocks.destroy',$medicine_stock->id)}}" method="POST">
            <a class="btn btn-info" href="{{route('medicine_stocks.show',$medicine_stock->id)}}">Show</a>

            <a class="btn btn-primary" href="{{route('medicine_stocks.edit',$medicine_stock->id)}}">Edit</a>

            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger">Delete</button>
            
         </form>
         </td>
    </tr>
    @endforeach

    </table>