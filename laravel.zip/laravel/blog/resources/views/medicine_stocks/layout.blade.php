<!Doctype html>
<html>
    <head>
       <title>Stock Management System</title>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrp.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            @yield('content')
        </div>
        
    </body>
</html>