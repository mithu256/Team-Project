<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Phamacist extends Model
{
    protected $fillable = [
        'Phm_Nic','Phm_Name','Phm_Email','Phm_password','Phm_address','Phm_Mobile_No'
    ];
}
