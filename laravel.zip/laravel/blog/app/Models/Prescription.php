<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Prescription extends Model
{
    protected $fillable = [
        'Pres_No','Phm_Nic','Pat_id','Diagnosis','Dosage','Med_Name'
    ];
}
