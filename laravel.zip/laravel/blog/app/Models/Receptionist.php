<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Receptionist extends Model
{
    protected $fillable = [
        'Rec_Nic','Rec_name','Rec_MobileNo','Rec_Email','Rec_password','Rec_address'
    ];
}
