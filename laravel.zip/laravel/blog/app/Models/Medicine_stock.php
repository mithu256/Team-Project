<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Medicine_stock extends Model
{
    protected $fillable = [
        'Med_No', 'Phm_Nic','Dosage','Consumption_time','Unit_Price','Exp_Date','Manu_Date','Quantity'
    ];
}
