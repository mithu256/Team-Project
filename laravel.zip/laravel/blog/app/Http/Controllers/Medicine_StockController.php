<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Medicine_StockController extends Controller
{
    public function index()
    {
        $medicine_stocks =Medicine_stock::latest()->paginate(5);
        return view('medicine_stocks.index',compact('medicine_stocks'))
          ->width('i',(request()->input('page',1) -1)*5);

    }
    public function create()
    {
        return view('medicine_stocks.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'Med_No'=>'required',
            'Med_Name'=>'required',
            'Dosage'=>'required',
            'Consumption_time'=>'required',
            'Unit_Price'=>'required',
            'Exp_Date'=>'required',
            'Manu_Date'=>'required',
            'Quantity'=>'required',
           ]);
           Medicine_stock::create($request->all());
           return redirect()->route('medicine_stocks.index')
           ->with('success','medicine_stocks created sussessfully');
    }
    public function show(Medicine_stock $medicine_stock)
    {
        return view('medicine_stocks.show',compact('medicine_stock'));
    }
    public function edit(Medicine_stock $medicine_stock)
    {
        return view('medicine_stocks.edit',compact('medicine_stock'));
    }
    public function update(Request $request,Medicine_stock $medicine_stock)
    {
        $request->validate([

        ]);
        $medicine_stock->update($request->all());

        return redirect()->route('medicine_stocks.index')

        ->with('success','medicine_stocks updated successfully');
    }
    public function destroy(Medicine_stock $medicine_stock)
    {
        $medicine_stock->delete();
        return redirect()->route('medicine_stocks.index')
        ->with('success','medicine_stocks deleted successfully');
    }
}
