<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\doctor;

class doctorController extends Controller
{
    function show()
    {
       return doctor::all();
        // return view('list');
    }
    public function index()
    {

    }
}
