

<?php $__env->startSection('main'); ?>
<div class="row">
 <div class="col-sm-8 offset-sm-2">
   <b> <c><h1 class="display">Phamacist Login </h1></c> </b> <br/>
        <?php if(isset(Auth::user()->email)): ?>
            <script>window.location="/success";</script>
        <?php endif; ?>
        <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">x</button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
        <?php endif; ?>
  <div>
  
      <form method="post" action="<?php echo e(url('/checklogin')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">    
              <label for="email">Email Id:</label>
              <input type="email" class="form-control" name="email"/>
          </div>

          <div class="form-group">
              <label for="password">Password:</label>
              <input type="password" class="form-control" name="password"/>
          </div>
          <div class="form-group">              
            <button type="submit" class="btn btn-primary-outline">Login</button>
          <div>
      </form>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/login.blade.php ENDPATH**/ ?>