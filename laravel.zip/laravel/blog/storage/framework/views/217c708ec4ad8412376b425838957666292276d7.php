<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Laravel Login App</title>
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
  <style>
  body
      {
          colour:blue;
      }
  body

  </style>
</head>

<body>
  <div class="container">
    <?php echo $__env->yieldContent('main'); ?>
  </div>
  <script src="<?php echo e(asset('js/app.js')); ?>" type="text/js"></script>
  
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/base.blade.php ENDPATH**/ ?>